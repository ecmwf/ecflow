#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>
#include <boost/serialization/base_object.hpp>
#include <boost/serialization/string.hpp>
#include <boost/serialization/vector.hpp>
#include <boost/serialization/shared_ptr.hpp>     // no need to include shared_ptr
#include <boost/serialization/export.hpp>

class Concrete {
public:
   Concrete(const std::string& name ) : name_(name) {}
   Concrete() {}
private:
    std::string name_;
    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive& ar,const unsigned int){
        ar & name_;
    }
};

class ConcreteContainer {
public:
  ConcreteContainer() {}
private:
    std::vector<boost::shared_ptr<Concrete> >  vec_;
    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive& ar,const unsigned int){
         ar & vec_;
    }
};

// Ok this correctly causes warning. Since we are not
// Serialising through a ptr to the base
//BOOST_CLASS_EXPORT(Concrete);

class Base {
public:
   Base(const std::string& name ) : name_(name) {}
   Base() {}
   virtual ~Base(){}
private:
    std::string name_;
    std::vector<boost::shared_ptr<Concrete> >  vec_;

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int) {
        ar & name_;
        ar & vec_;
     }
};

class Derived : public Base {
public:
   Derived(const std::string& name ) : Base(name) {}
   Derived() {}
private:
    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int) {
        ar & boost::serialization::base_object<Base>(*this);
    }
};

BOOST_CLASS_EXPORT(Derived);

