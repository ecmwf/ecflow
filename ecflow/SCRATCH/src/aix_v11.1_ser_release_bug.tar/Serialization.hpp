#ifndef SERIALIZATION_HPP_
#define SERIALIZATION_HPP_

/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8
// Name        :
// Author      : Avi
// Version     :
// Copyright   : This software is provided under the ECMWF standard software license agreement.
// Description :
/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8

#include <string>
#include <iostream>
#include <fstream>

#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>
#include <boost/noncopyable.hpp>

class Archive : private boost::noncopyable {
public:
	enum Type {
		TEXT =0

#ifdef TEST_BINARY_ARCHIVES
		, BINARY=1,
		PORTABLE_BINARY=2
#endif
		};

private:
	Archive();
};


namespace ecf {

template< typename T >
bool save(const std::string& fileName, const T& ts,  Archive::Type archiveType, bool debug)
{
  	try {
		switch (archiveType) {
			case Archive::TEXT: {
 				if (debug) std::cout << "Archive::TEXT Saving ";
 				std::ofstream ofs( fileName.c_str() );
				boost::archive::text_oarchive oa( ofs );
				oa << ts;
				break;
			}
#ifdef TEST_BINARY_ARCHIVES
			case Archive::BINARY: {
				if (debug) std::cout << "Archive::BINARY Saving ";
 				std::ofstream ofs( fileName.c_str(), std::ios::binary );
				boost::archive::binary_oarchive oa( ofs );
				oa << ts;
				break;
			}
			case Archive::PORTABLE_BINARY: {
				if (debug) std::cout << "Archive::PORTABLE_BINARY Saving ";
 				std::ofstream ofs( fileName.c_str(), std::ios::binary );
		        portable_binary_oarchive oa(ofs);
 				oa << ts;
				break;
			}
#endif
			default : assert(false);
		}
 		if (debug) std::cout << " OK \n";
 		return true;
	}
	catch (const boost::archive::archive_exception& ae) {
		std::cout << " save " << fileName << " failed. boost::archive exception: " << ae.what() << std::endl;
	}
	return false;
}

template< typename T >
bool restore(const std::string& fileName, T& restored,  Archive::Type archiveType, bool debug)
{
	try {
		switch (archiveType) {
			case Archive::TEXT: {
				if (debug) std::cout << "Archive::TEXT Restoring ";
  				std::ifstream ifs( fileName.c_str() );
				boost::archive::text_iarchive ia( ifs );
				ia >> restored;
				break;
			}
#ifdef TEST_BINARY_ARCHIVES
			case Archive::BINARY: {
				if (debug) std::cout << "Archive::BINARY Restoring ";
 				std::ifstream ifs( fileName.c_str(), std::ios::binary );
				boost::archive::binary_iarchive ia( ifs );
				ia >> restored;
				break;
			}
			case Archive::PORTABLE_BINARY: {
				if (debug) std::cout << "Archive::PORTABLE_BINARY Restoring ";
 				std::ifstream ifs( fileName.c_str(), std::ios::binary );
				portable_binary_iarchive ia( ifs );
				ia >> restored;
				break;
			}
#endif
			default : assert(false);
		}
 		if (debug) std::cout << " OK \n";
 		return true;
	}
	catch ( const boost::archive::archive_exception& ae ) {
		std::cout << "restore " << fileName << " failed. boost::archive exception: " << ae.what() << std::endl;
 	}
	return false;
}

}
#endif
