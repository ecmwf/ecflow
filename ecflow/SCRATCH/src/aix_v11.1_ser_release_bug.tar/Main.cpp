#define BOOST_TEST_MODULE TestANattr

/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8
// Name        :
// Author      : Avi
// Version     :
// Copyright   : This software is provided under the ECMWF standard software license agreement.
// Description :
//              This test shows that Saving via Base pointer fails on AIX
//              but ONLY when compile in release mode.
/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8

#include <boost/test/unit_test.hpp>
#include <boost/make_shared.hpp>

#include "RepeatAttr.hpp"
#include "SerializationTest.hpp"

using namespace std;
using namespace ecf;

// Globals used throughout the test
static bool debug = false;
static std::string fileName = "test.txt";
static std::vector< Archive::Type > archiveType()
{
	std::vector< Archive::Type > vec;
	vec.push_back(Archive::TEXT);
#ifdef TEST_BINARY_ARCHIVES
	vec.push_back(Archive::BINARY);
	vec.push_back(Archive::PORTABLE_BINARY);
#endif
	return vec;
}

BOOST_AUTO_TEST_SUITE( ANattrTestSuite )

BOOST_AUTO_TEST_CASE( test_RepeatAttr_serialisation )
{
	cout << "ANattr:: ...test_RepeatAttr_serialisation \n";
 	std::vector< Archive::Type > vec = archiveType();
	for(size_t i = 0; i < vec.size(); i++) {
		{
		   cout << "Save and Restore RepeatDate\n";
			RepeatDate saved("varname",20101210,20101230,3);
			doSaveAndRestore(fileName,saved,vec[i],debug);
		}
	}

	// test serialisation via base pointer.
	for(size_t i = 0; i < vec.size(); i++) {
		{
         cout << "Save and Restore RepeatDate via base pointer\n";
			Repeat saved(RepeatDate("varname",20101210,20101230,3));
			doSaveAndRestore(fileName,saved,vec[i],debug);
		}
	}
}

BOOST_AUTO_TEST_SUITE_END()

