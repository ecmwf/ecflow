#ifndef REPEATATTR_HPP_
#define REPEATATTR_HPP_
//============================================================================
// Name        :
// Author      : Avi
// Version     :
// Copyright   : This software is provided under the ECMWF standard software license agreement.
// Description :
//============================================================================

#include <ostream>

#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>
#include <boost/serialization/base_object.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/vector.hpp>         // no need to include <vector>
#include <boost/serialization/string.hpp>         // no need to include <string>
#include <boost/serialization/assume_abstract.hpp>

#include <boost/utility.hpp>
#include <boost/serialization/export.hpp>   // explicit code for exports (place last) , needed for BOOST_CLASS_EXPORT

/////////////////////////////////////////////////////////////////////////
// Node can only have one repeat.
//
class RepeatBase {
public:
	RepeatBase();
	virtual ~RepeatBase();

	virtual RepeatBase* clone() const = 0;
	virtual bool compare(RepeatBase*) const = 0;
	virtual std::string name() const = 0;
	virtual std::ostream& print(std::ostream&) const = 0;
	virtual bool valid() const = 0;
	virtual long value() const = 0;
	virtual void setToLastValue()  = 0;
	virtual std::string valueAsString() const = 0;
	virtual void reset()  = 0;
	virtual void increment() = 0;
	virtual bool isInfinite() const  = 0;
	virtual std::string toString() const = 0;

	virtual int length() const  = 0;     // for use by simulator
	virtual void truncate(int length) = 0;  // for use by simulator

private:
	friend class boost::serialization::access;
	template<class Archive>
	void serialize(Archive &, const unsigned int) {}
};

class RepeatDate : public RepeatBase {
public:
	RepeatDate( const std::string& variable, int start, int end, int delta = 1/* always in days*/);
	RepeatDate() :  start_(0), end_(0), delta_(0), value_(0)  {}

	void delta(int d) { delta_ = d;}
	bool operator==(const RepeatDate& rhs) const;

	virtual RepeatDate* clone() const { return new RepeatDate(name_, start_, end_, delta_) ; }
	virtual std::string name() const { return name_;}
	virtual bool compare(RepeatBase*) const;
	virtual std::ostream& print(std::ostream&) const;
	virtual bool valid() const { return (delta_ > 0) ? ( value_ <= end_) : (value_ >= end_); }
	virtual long value() const { return value_;}
	virtual std::string valueAsString() const;
	virtual void setToLastValue();
	virtual void reset() { value_ = start_;}
	virtual void increment();
	virtual bool isInfinite() const { return false;}
	virtual std::string toString() const;

	virtual int length() const; // for use by simulator
	virtual void truncate(int); // for use by simulator

private:
    std::string  name_;
    int  start_;
    int  end_;
    int  delta_;
    long  value_;

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int /*version*/) {
        ar & boost::serialization::base_object<RepeatBase>(*this);
     	  ar & name_;
        ar & start_;
        ar & end_;
        ar & delta_;
        ar & value_;
    }
};

class Repeat {
public:
	Repeat(); // for serialisation
	Repeat( const RepeatDate& );
	Repeat( const Repeat& );
	Repeat& operator=(const Repeat& rhs);
	~Repeat();

	std::string name() const                     { return repeatType_->name();}
	std::ostream& print(std::ostream& os) const  { return repeatType_->print(os);}
	bool operator==(const Repeat& rhs) const     { return repeatType_->compare(rhs.repeatType_); }
  	bool valid() const                           { return repeatType_->valid();}
  	long value() const                           { return repeatType_->value();}
    void setToLastValue()                        { repeatType_->setToLastValue(); }
	std::string valueAsString() const            { return repeatType_->valueAsString(); }
  	void reset()                                 { repeatType_->reset();}
  	void increment()                             { repeatType_->increment();}
	bool isInfinite() const                      { return repeatType_->isInfinite();}
	std::string toString() const                 { return repeatType_->toString();}

	int length() const                           { return repeatType_->length();}         // for simulator only
	void truncate(int length)                    { return repeatType_->truncate(length);} // for simulator only

private:
	RepeatBase* repeatType_;

	friend class boost::serialization::access;
	template<class Archive>
	void serialize(Archive & ar, const unsigned int /*version*/) {

// This seems to fix, bug with release version of v11.1
//#if defined(AIX)
//    	ar.register_type(static_cast<RepeatDate *>(NULL));
//#endif
	    ar & repeatType_;
 	}
};

BOOST_CLASS_EXPORT_KEY(RepeatDate)
#endif
