//============================================================================
// Name        : NodeTree.cpp
// Author      : Avi
// Version     :
// Copyright   : This software is provided under the ECMWF standard software license agreement.
// Description :
//============================================================================

#include <assert.h>
#include <sstream>

#include <boost/foreach.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/date_time/posix_time/posix_time_types.hpp>

#include "RepeatAttr.hpp"
//#include "Indentor.hpp"

using namespace std;
using namespace boost::gregorian;
using namespace boost::posix_time;

RepeatBase::RepeatBase() {}
RepeatBase::~RepeatBase() {}

/////////////////////////////////////////////////////////////////////////////////////

Repeat::Repeat() : repeatType_(NULL) {}
Repeat::Repeat( const RepeatDate& r) : repeatType_(new RepeatDate(r)) {}

Repeat::~Repeat() { delete repeatType_;}

Repeat::Repeat( const Repeat& rhs) : repeatType_(NULL)
{
	delete repeatType_; repeatType_ = NULL;
	repeatType_ = rhs.repeatType_->clone();
}

Repeat& Repeat::operator=(const Repeat& rhs)
{
	delete repeatType_; repeatType_ = NULL;
	repeatType_ = rhs.repeatType_->clone();
	return *this;
}

////////////////////////////////////////////////////////////////////////////////////////

RepeatDate::RepeatDate( const std::string& variable,
                        int start,
                        int end,
                        int delta /* always in days*/
) : name_(variable), start_(start), end_(end), delta_(delta), value_(start)
{
	if (start > end) {
		throw std::runtime_error("Invalid Repeat date: The end must be greater than the start date");
	}
	std::string theStart = boost::lexical_cast< std::string >(start);
	if (theStart.size() != 8) {
		throw std::runtime_error("Invalid Repeat date: The start is not a valid date. Please use yyyymmdd format.");
 	}
	std::string theEnd = boost::lexical_cast< std::string >(end);
	if (theEnd.size() != 8) {
		throw std::runtime_error("Invalid Repeat date: The end is not a valid date. Please use yyyymmdd format.");
 	}
}

bool RepeatDate::compare(RepeatBase* rb) const
{
	RepeatDate* rhs = dynamic_cast<RepeatDate*>(rb);
	if(!rhs) return false;
	return operator==(*rhs);
}

void RepeatDate::setToLastValue()
{
	if (delta_ > 0) value_ = end_ + 1;
	else            value_ = end_ - 1;
#ifdef DEBUG
	assert(!valid());
#endif
}

std::ostream& RepeatDate::print(std::ostream& os) const
{
//	Indentor in;
//	Indentor::indent(os) << "repeat date " << name_ << " " << start_ << " " << end_ << " " << delta_ << "\n";
	return os;
}

bool RepeatDate::operator==(const RepeatDate& rhs) const
{
	if (name_ != rhs.name_) {
		return false;
	}
	if (start_ != rhs.start_) {
		return false;
	}
	if (end_ != rhs.end_) {
		return false;
	}
	if (delta_ != rhs.delta_) {
		return false;
	}
	return true;
}

std::string RepeatDate::valueAsString() const
{
	/// will throw a boost::bad_lexical_cast& if value is not convertible to a string
 	try {
		return boost::lexical_cast< std::string >( value_ );
	}
	catch ( boost::bad_lexical_cast& ) { assert(false);}
	return string();
}


long sms_repeat_julian_to_date(long jdate)
{
	long x,y,d,m,e;
	long day,month,year;

	x = 4 * jdate - 6884477;
	y = (x / 146097) * 100;
	e = x % 146097;
	d = e / 4;

	x = 4 * d + 3;
	y = (x / 1461) + y;
	e = x % 1461;
	d = e / 4 + 1;

	x = 5 * d - 3;
	m = x / 153 + 1;
	e = x % 153;
	d = e / 5 + 1;

	if( m < 11 )
		month = m + 2;
	else
		month = m - 10;


	day = d;
	year = y + m / 11;

	return year * 10000 + month * 100 + day;
}

long sms_repeat_date_to_julian(long ddate)
{
	long  m1,y1,a,b,c,d,j1;
	long month,day,year;

	year = ddate / 10000;
	ddate %= 10000;
	month  = ddate / 100;
	ddate %= 100;
	day = ddate;

	if (month > 2)
	{
		m1 = month - 3;
		y1 = year;
	}
	else
	{
		m1 = month + 9;
		y1 = year - 1;
	}
	a = 146097*(y1/100)/4;
	d = y1 % 100;
	b = 1461*d/4;
	c = (153*m1+2)/5+day+1721119;
	j1 = a+b+c;

	return(j1);
}

void RepeatDate::increment()
{
    long julian = sms_repeat_date_to_julian(value_ + delta_);
    value_ = sms_repeat_julian_to_date(julian);
}

int RepeatDate::length() const
{
	return 1;
}

void RepeatDate::truncate(int theLength)
{
	assert(theLength < length());
	cout << "   RepeatDate::truncate by " <<  theLength << " BEFORE " << toString();

	long julian = 0;
	if (delta_ > 0) julian = sms_repeat_date_to_julian(start_ + theLength);
	else            julian = sms_repeat_date_to_julian(start_ - theLength);

	end_ = sms_repeat_julian_to_date(julian);

	cout << " AFTER " << toString() << "\n";
}


std::string RepeatDate::toString() const
{
	std::stringstream ss;
	ss << "repeat date " << start_ << " " << end_ << " " << delta_ << " value(" << value_ << ")";
	return ss.str();
}

#include <boost/serialization/export.hpp>   // explicit code for exports (place last) , needed for BOOST_CLASS_EXPORT
BOOST_CLASS_EXPORT_IMPLEMENT(RepeatDate);

