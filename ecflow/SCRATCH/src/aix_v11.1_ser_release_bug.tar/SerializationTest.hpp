#ifndef SERIALIZATION_TEST_HPP_
#define SERIALIZATION_TEST_HPP_

/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8
// Name        :
// Author      : Avi
// Version     :
// Copyright   : This software is provided under the ECMWF standard software license agreement.
// Description :
/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8

#include "Serialization.hpp"

namespace ecf {

// The following template  functions are used test/debug only
template < typename T >
void doRestore(const std::string& fileName, const T& saved,  Archive::Type archiveType, bool debug)
{
	T restored;
	BOOST_CHECK_MESSAGE(ecf::restore(fileName,restored,archiveType,debug),"Restore failed");
	BOOST_CHECK_MESSAGE(saved == restored," save and restored don't match for " << archiveType);
	std::remove(fileName.c_str());
}


template < typename T >
void doSaveAndRestore(const std::string& fileName, const T& saved, Archive::Type archiveType, bool debug)
{
	BOOST_CHECK_MESSAGE(ecf::save(fileName,saved,archiveType,debug),"Save failed");
	doRestore(fileName,saved,archiveType,debug);
}


template < typename T >
void doSaveAndRestore(const std::string& fileName, Archive::Type archiveType, bool debug)
{
	T saved;
	doSaveAndRestore(fileName,saved,archiveType,debug);
}

}
#endif
