//================ Main.cpp =========================
// This example demonstrates a  bug in portable binary format on AIX when serialising -1
// that is specific only to the AIX compiler/platform
// (i.e HPUX/Acc and linux/gcc run without any problems)
// However on AIX on the restore, an exception is thrown
// in load_impl(..)
//
// This test consists of 1 files
// 1/ Main.cpp
//
//  It appears that when restoring an integer of value -1, it binds to:
//
//    void load(T & t){
//        boost::intmax_t l;
//        load_impl(l, sizeof(T));
//        // use cast to avoid compile time warning
//        //t = static_cast< T >(l);
//        t = T(l);
//    }
//
//    void load_impl(boost::intmax_t & l, char maxsize);
//
//  This appears to be the wrong load as the signature of load_impl()
//  will lead to truncation ???
//
//2/ Note You will need to pull out and compile the portable
//   binary archive from the boost serialisation example dir.

#include <sstream>
#include <ostream>
#include <iostream>
#include <fstream>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>
#include "portable_binary_oarchive.hpp"
#include "portable_binary_iarchive.hpp"
#include <boost/serialization/serialization.hpp>

using namespace std;

 void save(const std::string& fileName, const int& ts, bool textArchive)
{
   if ( textArchive ) std::cout << "Text archive Saving " << ts ;
   else               std::cout << "portable binary archive Saving " << ts;
   try {
      if (textArchive) {
         std::ofstream ofs( "fred.txt" );
         boost::archive::text_oarchive ar( ofs );
         ar << ts;
      }
      else {
         std::ofstream ofs( fileName.c_str(), ios::binary );
            portable_binary_oarchive ar(ofs);
         ar << ts;
      }

      std::cout << " OK \n";
   }
   catch (const boost::archive::archive_exception& ae) {
      std::cout << " save " << fileName
      << " failed. boost::archive exception for TimeStruct "
       << ": " << ae.what() << std::endl;
   }
}

void restore(const std::string& fileName, int& restored, bool textArchive)
{
   if ( textArchive ) std::cout << "Text archive Restoring ";
   else               std::cout << "portable binary archive Restoring " ;

   try {
      if ( textArchive ) {
         std::ifstream ifs( fileName.c_str() );
         boost::archive::text_iarchive ar( ifs );
         ar >> restored;
      }
      else {
         std::ifstream ifs( fileName.c_str(), ios::binary );
         portable_binary_iarchive ar( ifs );
         ar >> restored;
      }

      std::cout  << restored << " OK \n";
   }
   catch ( const boost::archive::archive_exception& ae ) {
      std::cout << " restore " << fileName
      << " failed. boost::archive exception for  TimeStruct "
       << ": " << ae.what() << std::endl;
   }
}

int main()
{
   {
      int saved  = -1;
      save("fred.txt",saved,true);

      int restored = 44;
      restore("fred.txt",restored,true);
      assert(saved == restored);
   }
   {
      int saved = -1;
      save("fred.txt",saved,false);
      int restored = 44;
      restore("fred.txt",restored,false);
      assert(saved == restored);
   }
   return 0;
}
