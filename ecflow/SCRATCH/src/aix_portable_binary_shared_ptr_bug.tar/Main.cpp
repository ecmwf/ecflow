// ========================= main.cpp  ===============================
// This file is used to show problem with the portable binary archive
// when using the AIX/v11.1 compiler
//
// This test passes on Linux:gcc-4.2.1/HPUX:acc but crashes on AIX.
//
#include <assert.h>
#include <iostream>
#include <fstream>
#include "portable_binary_oarchive.hpp"
#include "portable_binary_iarchive.hpp"
#include <boost/serialization/string.hpp>
#include <boost/serialization/shared_ptr.hpp>
#include <boost/serialization/weak_ptr.hpp>

class CLimit {
public:
   CLimit(const std::string& name) : name_(name) {}
   CLimit() {}
   const std::string& name() const { return  name_;}
private:
   std::string name_;
   friend class boost::serialization::access;
   template<class Archive>
   void serialize(Archive & ar, const unsigned int) {
      ar & name_;
   }
};

class InLimit {
public:
   InLimit(const std::string& name,boost::shared_ptr<CLimit> l)
   : name_(name), limit_(l) {}
   InLimit() {}
   const std::string& name() const { return  name_;}
   CLimit* limit() const { return limit_.get();}
private:
   std::string 			     name_;
   boost::shared_ptr<CLimit> limit_;

   friend class boost::serialization::access;
   template<class Archive>
   void serialize(Archive & ar, const unsigned int) {
      ar & name_;
      ar & limit_;
   }
};

int main()
{
	std::string fileName= "pba.txt";
	{
		const InLimit saved;
		std::ofstream ofs( fileName.c_str(), std::ios::binary);
		portable_binary_oarchive oa(ofs);
		oa << saved;
      std::cout << "saved OK\n";
	}
	{
		InLimit restored;
 		std::ifstream ifs( fileName.c_str(), std::ios::binary);
		portable_binary_iarchive ia( ifs );
		ia >> restored;
 		std::cout << "restored OK\n";
	}
	return 0;
}
