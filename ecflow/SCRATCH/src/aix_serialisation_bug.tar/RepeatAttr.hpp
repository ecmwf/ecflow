#ifndef REPEATATTR_HPP_
#define REPEATATTR_HPP_

#include <ostream>

#include <boost/operators.hpp>
#include <boost/utility.hpp>

#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>
#include <boost/serialization/base_object.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/string.hpp>         // no need to include <string>
#include <boost/serialization/assume_abstract.hpp>

class RepeatBase {
public:
	RepeatBase();
	virtual ~RepeatBase();

	virtual RepeatBase* clone() const = 0;
	virtual bool compare(RepeatBase*) const = 0;
	virtual std::string name() const = 0;
	virtual std::ostream& print(std::ostream&) const = 0;
	virtual bool valid() const = 0;
	virtual long value() const = 0;
	virtual std::string valueAsString() const = 0;
	virtual void reset()  = 0;
	virtual void increment() = 0;
	virtual bool isInfinite() const  = 0;
	virtual std::string dump() const = 0;

	virtual int length() const  = 0;     // for use by simulator
	virtual void truncate(int length) = 0;  // for use by simulator

private:
	friend class boost::serialization::access;
	template<class Archive>
	void serialize(Archive &, const unsigned int) {}
};

class RepeatDate : public RepeatBase {
public:
	RepeatDate(
	       const std::string& variable,
	       int start,
	       int end,
	       int delta /* always in days*/
	       ) : name_(variable), start_(start), end_(end), delta_(delta), value_(start) {}
	RepeatDate() :  start_(0), end_(0), delta_(0), value_(0)  {}

	void delta(int d) { delta_ = d;}
	bool operator==(const RepeatDate& rhs) const;

	virtual RepeatDate* clone() const ;
	virtual std::string name() const { return name_;}
	virtual bool compare(RepeatBase*) const;
	virtual std::ostream& print(std::ostream&) const;
	virtual bool valid() const { return (delta_ > 0) ? ( value_ <= end_) : (value_ >= end_); }
	virtual long value() const { return value_;}
	virtual std::string valueAsString() const;
	virtual void reset() { value_ = start_;}
	virtual void increment();
	virtual bool isInfinite() const { return false;}
	virtual std::string dump() const;

	virtual int length() const; // for use by simulator
	virtual void truncate(int); // for use by simulator

private:
    std::string  name_;
    int  start_;
    int  end_;
    int  delta_;
    long  value_;

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int /*version*/) {
        ar & boost::serialization::base_object<RepeatBase>(*this);
     	ar & name_;
        ar & start_;
        ar & end_;
        ar & delta_;
        ar & value_;
    }
};

class Repeat {
public:
	Repeat(); // for serialisation
	Repeat( const RepeatDate& );
	Repeat( const Repeat& );
	Repeat& operator=(const Repeat& rhs);
	~Repeat();

	std::string name() const                     { return repeatType()->name();}
	std::ostream& print(std::ostream& os) const  { return repeatType()->print(os);}
	bool operator==(const Repeat& rhs) const     { return repeatType()->compare(rhs.repeatType()); }
  	bool valid() const                           { return repeatType()->valid();}
  	long value() const                           { return repeatType()->value();}
	std::string valueAsString() const            { return repeatType()->valueAsString(); }
  	void reset()                                 { return repeatType()->reset();}
  	void increment()                             { return repeatType()->increment();}
	bool isInfinite() const                      { return repeatType()->isInfinite();}
	std::string dump() const                     { return repeatType()->dump();}

	int length() const                           { return repeatType()->length();}         // for simulator only
	void truncate(int length)                    { return repeatType()->truncate(length);} // for simulator only

private:
	RepeatBase* repeatType_;
	RepeatBase* repeatType() const;

	friend class boost::serialization::access;
	template<class Archive>
	void serialize(Archive & ar, const unsigned int /*version*/) {
	    ar & repeatType_;
 	}
};

#endif
