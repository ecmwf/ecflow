#ifndef NODE_HPP_
#define NODE_HPP_

#include "RepeatAttr.hpp"

#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>
#include <boost/serialization/string.hpp>         // no need to include <string>

class Node   {
public:
 	Node( const std::string& name ) :  name_(name), repeat_(NULL) {}
 	Node() : repeat_(NULL) {}
	virtual ~Node() {}

 	const std::string& name() const { return name_; }

 	bool operator==(const Node& rhs) const { return name_ == rhs.name_;}

	bool addRepeat( const Repeat& r ) {
		if (repeat_) return false;
	 	repeat_ = new Repeat(r);
	 	return true;
	}

private:

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int /*version*/) {
         ar & name_;
         ar & repeat_;
    }

    std::string name_;
    Repeat*     repeat_;
};

#endif
