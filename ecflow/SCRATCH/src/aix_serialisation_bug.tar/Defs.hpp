#ifndef DEFS_HPP_
#define DEFS_HPP_

#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>
#include <boost/serialization/utility.hpp>
#include <boost/serialization/vector.hpp> // no need to include <vector>
#include <boost/serialization/string.hpp> // no need to include <string>

#include "Suite.hpp"
#include <fstream>

class Defs {
public:
	Defs( const std::string& name ) : fileName_(name) {}
	Defs() {}
	~Defs() {}

 	const std::string& fileName() const { return fileName_;}
	void fileName(const std::string& f) { fileName_ = f;}

	void  addSuite(std::auto_ptr<Suite> s){ suiteVec_.push_back(s.release()); }

	bool operator==(const Defs& rhs) const {
		if ( fileName_ != rhs.fileName_ )  {
			std::cout << "file names dont match\n";
			return false;
		}
		if ( suiteVec_.size() != rhs.suiteVec_.size()) {
			std::cout << " suite vec size dont match \n";
			return false;
		}
		for(unsigned i =0; i < suiteVec_.size(); ++i) {
			if ( !( *(suiteVec_[i]) == *(rhs.suiteVec_[i]) ))  {
				std::cout << " suite dont match \n";
				return false;
			}
		}
	 	return true;
	}

	void save() const;
	void restore();

private:
	std::string fileName_;
	std::vector<Suite*> suiteVec_;

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int /*version*/) {
        ar & fileName_;
        ar & suiteVec_;
    }
};

#endif
