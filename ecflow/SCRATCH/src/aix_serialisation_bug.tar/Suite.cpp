#include "Suite.hpp"
#include <boost/serialization/export.hpp>    // explicit code for exports (place last)

Suite::Suite( const std::string& name ) :
	NodeContainer( name ), name2_( name ){}

Suite::Suite() {}

Suite::~Suite() {}

BOOST_CLASS_EXPORT(Suite)
