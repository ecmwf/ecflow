#include "Suite.hpp"
#include "Defs.hpp"

using namespace std;

// This is a test case that shows bugs with boost serialisation and AIX v10.1 compiler
// Please note minor change to class hierarchy can make test run/fail
// It should print out reached the end if all is OK.

int main()
{
	Defs saveDefs("saveFile.txt");
	saveDefs.addSuite( std::auto_ptr<Suite>(new Suite("s1") ));
	saveDefs.addSuite( std::auto_ptr<Suite>(new Suite("s2") ));

	std::auto_ptr<Suite> suite(new Suite("s3") );
	suite->addRepeat( RepeatDate("YMD",20090916,20090930,1));
	saveDefs.addSuite( suite );

	saveDefs.save();

	{
  		Defs loadDefs(saveDefs.fileName());
 		loadDefs.restore();
		assert( saveDefs == loadDefs );
  	}
	cout << "reached the end\n";
	return 0;
}
