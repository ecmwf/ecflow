#include "RepeatAttr.hpp"
#include <assert.h>
#include <sstream>
#include <boost/serialization/export.hpp>

using namespace std;

RepeatBase::RepeatBase() {}
RepeatBase::~RepeatBase() {}

////////////////////////////////////////////////////////////////////////////////////////

Repeat::Repeat() : repeatType_(NULL) {}
Repeat::Repeat( const RepeatDate& r) : repeatType_(new RepeatDate(r)) {}
Repeat::~Repeat() { delete repeatType_;}

Repeat::Repeat( const Repeat& rhs) : repeatType_(NULL)
{
	delete repeatType_; repeatType_ = NULL;
	repeatType_ = rhs.repeatType_->clone();
}

Repeat& Repeat::operator=(const Repeat& rhs)
{
	delete repeatType_; repeatType_ = NULL;
	repeatType_ = rhs.repeatType_->clone();
	return *this;
}

RepeatBase* Repeat::repeatType() const
{
	return repeatType_;
}

////////////////////////////////////////////////////////////////////////////////////////

RepeatDate* RepeatDate::clone() const
{
	return new RepeatDate(name_, start_, end_, delta_) ;
}

bool RepeatDate::compare(RepeatBase* rb) const
{
	RepeatDate* rhs = dynamic_cast<RepeatDate*>(rb);
	if(!rhs) return false;
	return operator==(*rhs);
}

std::ostream& RepeatDate::print(std::ostream& os) const
{
	return os;
}

bool RepeatDate::operator==(const RepeatDate& rhs) const
{
	if (name_ != rhs.name_) {
		return false;
	}
	if (start_ != rhs.start_) {
		return false;
	}
	if (end_ != rhs.end_) {
		return false;
	}
	if (delta_ != rhs.delta_) {
		return false;
	}
	return true;
}

std::string RepeatDate::valueAsString() const{return string();}

void RepeatDate::increment(){}

int RepeatDate::length() const{return 1;}

void RepeatDate::truncate(int theLength){}

std::string RepeatDate::dump() const
{
	std::stringstream ss;
	ss << "repeat date " << start_ << " " << end_ << " " << delta_ << " value(" << value_ << ")";
	return ss.str();
}

BOOST_SERIALIZATION_ASSUME_ABSTRACT(RepeatBase);
BOOST_CLASS_EXPORT(RepeatDate);

