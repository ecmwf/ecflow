#include "Defs.hpp"


void Defs::save() const
{
	std::cout << "Save the defs file " << fileName_ << "\n";
	std::ofstream ofs( fileName_.c_str() );
	boost::archive::text_oarchive oa( ofs );
	oa << *this;
	std::cout << "Saved\n";
}

void Defs::restore()
{
	std::cout << "Restore the defs file " << fileName_ << "\n";
	if (!fileName_.empty()) {

		std::ifstream ifs( fileName_.c_str());
		boost::archive::text_iarchive ia(ifs);
		ia >> (*this);
		std::cout << "Restored\n";
	}
}
