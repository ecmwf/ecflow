#ifndef NODE_CONTAINER_HPP_
#define NODE_CONTAINER_HPP_

#include "Node.hpp"

#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>
#include <boost/serialization/string.hpp>         // no need to include <string>

// Note: if the functionality in class Node, is pulled up, into this class
// then test will no longer fail.

class NodeContainer : public Node  {
public:
 	NodeContainer( const std::string& name ) :  Node(name),name5_(name) {}
 	NodeContainer() {}
	virtual ~NodeContainer() {}

 	bool operator==(const NodeContainer& rhs) const { return Node::operator==(rhs); }

private:

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int /*version*/) {
        ar & boost::serialization::base_object<Node>(*this);
        ar & name5_;
     }

    std::string name5_;
};

#endif
