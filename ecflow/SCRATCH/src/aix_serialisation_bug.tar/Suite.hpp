#ifndef SUITE_HPP_
#define SUITE_HPP_

#include "NodeContainer.hpp"

#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>
#include <boost/serialization/base_object.hpp>
#include <boost/serialization/string.hpp>

class Suite : public NodeContainer {
public:
	Suite( const std::string& name );
 	Suite() ;
	virtual ~Suite();

  	bool operator==(const Suite& rhs) const{ return NodeContainer::operator==(rhs);}

private:

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int /*version*/) {
        // serialise base class information
        ar & boost::serialization::base_object<NodeContainer>(*this);
        ar & name2_;
     }

    std::string name2_;
};

#endif
