#ifndef SUITE_CHANGED_HPP_
#define SUITE_CHANGED_HPP_

/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8
// Name        :
// Author      : Avi
// Version     : Beta version for test use only
// Copyright   : This software is provided under the ECMWF standard software license agreement.
// Description :
/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8

#include <boost/noncopyable.hpp>
#include "Suite.hpp"

// Determine if suite was changed or modified if so, update suite change no
// This mechanism was used because, when changing some attributes, we can not
// immediately access the parent suites, to update the change numbers.
//
// When given a choice between where to add SuiteChanged, i.e in Node Tree or Commands
// Generally favour commands, as it will require less maintenance over time.
//
// This mechanism was added specifically to support changes over client handles
// i.e suites are added to handles, hence we need a way to determine which
// suites (and hence handle) changed, and hence minimise the need for updates.

class SuiteChanged  : private boost::noncopyable {
public:
   SuiteChanged(suite_ptr s);
   ~SuiteChanged();
private:
   weak_suite_ptr suite_;
   unsigned int state_change_no_;
   unsigned int modify_change_no_;
};


#endif
