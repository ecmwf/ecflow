#include "Suite.hpp"
#include <boost/make_shared.hpp>

Suite::Suite( const std::string& name ) :
	NodeContainer( name ), name2_( name ){}

Suite::Suite() {}

Suite::~Suite() {}

suite_ptr Suite::create(const std::string& name)
{
   return boost::make_shared<Suite>( name );
}

