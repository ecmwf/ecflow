#include "SuiteChanged.hpp"
#include <iostream>

SuiteChanged::SuiteChanged(suite_ptr s)
: suite_(s)
   {}

SuiteChanged::~SuiteChanged()
{
   suite_ptr suite = suite_.lock();
   if (suite.get()) {
      std::cout << "SuiteChanged::~SuiteChanged() " << suite->name() << "\n";
   }
}

