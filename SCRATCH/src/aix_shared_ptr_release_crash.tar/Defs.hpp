#ifndef DEFS_HPP_
#define DEFS_HPP_

#include "Suite.hpp"
#include <fstream>
#include <vector>
#include <iostream>
#include <limits>

class Defs {
public:
	Defs( const std::string& name ) : fileName_(name) {}
	Defs() {}
	~Defs() {}

 	const std::string& fileName() const { return fileName_;}
	void fileName(const std::string& f) { fileName_ = f;}

   void addSuite(suite_ptr,size_t position = std::numeric_limits<std::size_t>::max());
   suite_ptr findSuite(const std::string& name) const;

	bool operator==(const Defs& rhs) const {
		if ( fileName_ != rhs.fileName_ )  {
			std::cout << "file names dont match\n";
			return false;
		}
		if ( suiteVec_.size() != rhs.suiteVec_.size()) {
			std::cout << " suite vec size dont match \n";
			return false;
		}
		for(unsigned i =0; i < suiteVec_.size(); ++i) {
			if ( !( *(suiteVec_[i]) == *(rhs.suiteVec_[i]) ))  {
				std::cout << " suite dont match \n";
				return false;
			}
		}
	 	return true;
	}

private:
   void add_suite_only(suite_ptr, size_t position);

	std::string fileName_;
	std::vector<suite_ptr> suiteVec_;
};

#endif
