#include "Defs.hpp"
#include "SuiteChanged.hpp"
#include <stdexcept>


void Defs::addSuite(suite_ptr s, size_t position)
{
   if (findSuite(s->name()).get()) {
      throw std::runtime_error( "Add suite failed");
   }
   add_suite_only( s , position);
}


void Defs::add_suite_only(suite_ptr s, size_t position)
{
   SuiteChanged changed(s);
   s->set_defs(this);
   if (position >= suiteVec_.size()) {
      suiteVec_.push_back(s);
   }
   else {
      suiteVec_.insert( suiteVec_.begin() + position, s);
   }
}

suite_ptr Defs::findSuite(const std::string& name) const
{
   size_t theSuiteVecSize = suiteVec_.size();
   for(size_t s = 0; s < theSuiteVecSize; s++) {
      if (suiteVec_[s]->name() == name) {
         return suiteVec_[s];
      }
   }
   return suite_ptr();
}
