#ifndef NODE_HPP_
#define NODE_HPP_

#include <string>
#include <fstream>
#include <boost/enable_shared_from_this.hpp>
#include <boost/noncopyable.hpp>

class Node  : public boost::enable_shared_from_this<Node>, private boost::noncopyable {
public:
 	Node( const std::string& name ) :  name_(name) {}
 	Node() {}
	virtual ~Node() {}

 	const std::string& name() const { return name_; }

   std::ostream& print(std::ostream& os) const { os << name_; return os ;}
 	bool operator==(const Node& rhs) const { return name_ == rhs.name_;}

private:

    std::string name_;
};

#endif
