#ifndef SUITE_HPP_
#define SUITE_HPP_

#include "NodeContainer.hpp"

#include <boost/shared_ptr.hpp>
#include <boost/weak_ptr.hpp>

class Suite;
class Defs;
typedef boost::shared_ptr<Suite>  suite_ptr;
typedef boost::weak_ptr<Suite> weak_suite_ptr;

class Suite : public NodeContainer {
public:
	Suite( const std::string& name );
 	Suite() ;
	virtual ~Suite();
   static suite_ptr create(const std::string& name);

  	bool operator==(const Suite& rhs) const{ return NodeContainer::operator==(rhs);}

  	void set_defs(Defs* d) { defs_ = d;}

private:
   Defs*                        defs_;              // *NOT* persisted, set by parent Defs

    std::string name2_;
};

#endif
