#include "Suite.hpp"
#include "Defs.hpp"

using namespace std;

// This test is a FAILED attempt to reproduce a crash
// with boost shared ptr in release mode of the compiler

int main()
{
   cout << "Start\n";

	Defs defs("saveFile.txt");


	suite_ptr suite =  Suite::create("s1");

	{
	   Suite* s_ptr =  suite.get();
	   cout << "name = " << s_ptr->name() << "\n";
	}

	defs.addSuite(suite);

	cout << "reached the end\n";
	return 0;
}
