#ifndef NODE_CONTAINER_HPP_
#define NODE_CONTAINER_HPP_

#include "Node.hpp"

// Note: if the functionality in class Node, is pulled up, into this class
// then test will no longer fail.

class NodeContainer : public Node  {
public:
 	NodeContainer( const std::string& name ) :  Node(name),name5_(name) {}
 	NodeContainer() {}
	virtual ~NodeContainer() {}

 	bool operator==(const NodeContainer& rhs) const { return Node::operator==(rhs); }

private:

    std::string name5_;
};

#endif
