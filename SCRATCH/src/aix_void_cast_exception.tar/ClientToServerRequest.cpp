//================ ClienttToServerRequest.cpp =========================
#include <assert.h>
#include <fstream>
#include "ClientToServerRequest.hpp"

using namespace std;

std::ostream& ClientToServerRequest::print( std::ostream& os ) const {
	if (cmd_.get())  return cmd_->print(os);
	return os << "NULL request";
}

bool ClientToServerRequest::operator==(const ClientToServerRequest& rhs) const
{
	if (!cmd_.get() && !rhs.cmd_.get()) return true;
	if (cmd_.get() && !rhs.cmd_.get())  return false;
	if (!cmd_.get() && rhs.cmd_.get())  return false;
	return (cmd_->equals(rhs.cmd_.get()));
}

void ClientToServerRequest::save(const std::string& fileName) const
{
	try {
		std::ofstream ofs( fileName.c_str() );
		boost::archive::text_oarchive ar( ofs );

		// Comment out code below cause a void cast exception.
		// i.e base /derived relationship has not been registered
//	    ar.register_type(static_cast<BeginCmd *>(NULL));
//	    ar.register_type<BeginCmd>();
	    ar << *this;
	}
	catch (const boost::archive::archive_exception& ae) {
		std::cout << "Request::save " << fileName
		<< " failed. boost::archive exception for request "
	    << this << " " << ": " << ae.what() << std::endl;
	}
}

void ClientToServerRequest::restore(const std::string& fileName)
{
	try {
		std::ifstream ifs( fileName.c_str() );
		boost::archive::text_iarchive ar( ifs );
//	    ar.register_type(static_cast<BeginCmd *>(NULL));
//	    ar.register_type<BeginCmd>();
		ar >> (*this);
	}
	catch ( const boost::archive::archive_exception& ae ) {
		std::cout << "Request::restore " << fileName
		<< " failed. boost::archive exception for request "
	    << this << " " << ": " << ae.what() << std::endl;
 	}
}

std::ostream& operator<<( std::ostream& os, const ClientToServerRequest& d ) {
	return d.print( os );
}
