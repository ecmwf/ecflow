//================ Cmd.cpp =========================
#include <iostream>
#include "Cmd.hpp"
#include <boost/serialization/export.hpp>

using namespace std;
using namespace boost;

// ===================================================

Cmd::~Cmd() {}

// ====================================================

bool ClientToServerCmd::equals(Cmd* rhs) const
{
	ClientToServerCmd* rhs_Cmd = dynamic_cast<ClientToServerCmd*>(rhs);
	if ( rhs_Cmd )  {
		return user_ == rhs_Cmd->user();
	}
 	return false;
}

// ====================================================

std::ostream& BeginCmd::print(std::ostream& os) const
{
	if (suiteName_.empty())  return os << "command:Begin [ <ALL> ]";
	return os << "command:Begin [ " << suiteName_ << " ]";
}

bool BeginCmd::equals(Cmd* rhs) const
{
	BeginCmd* the_rhs = dynamic_cast< BeginCmd* > ( rhs );
	if ( !the_rhs ) return false;
	if (suiteName_ != the_rhs->suiteName()) return false;
	if (createJobs_ != the_rhs->createJobs()) return false;
	return ClientToServerCmd::equals(rhs);
}

//================================================

std::ostream& operator<<(std::ostream& os, const BeginCmd& c)
{ return c.print(os); }

BOOST_CLASS_EXPORT(BeginCmd)

