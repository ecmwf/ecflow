//================ Cmd.hpp =========================
#ifndef CMD_HPP_
#define CMD_HPP_

#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>

#include <boost/serialization/base_object.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/assume_abstract.hpp>
#include <boost/serialization/shared_ptr.hpp>
#include <boost/serialization/string.hpp>


class Cmd {
public:
	virtual ~Cmd();
	virtual std::ostream& print(std::ostream& os) const = 0;
	virtual bool equals(Cmd* rhs) const = 0;
protected:
	Cmd(){}
private:
    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive &ar, const unsigned int /*version*/) {}
};
BOOST_SERIALIZATION_ASSUME_ABSTRACT(Cmd)


class ClientToServerCmd : public Cmd {
public:
 	virtual bool equals(Cmd* rhs) const;
 	const std::string& user() const { return user_;}
protected:
	ClientToServerCmd() {}
private:
 	std::string user_;

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive &ar, const unsigned int /*version*/) {
 		ar & boost::serialization::base_object< Cmd >( *this );
 		ar & user_;
    }
};
BOOST_SERIALIZATION_ASSUME_ABSTRACT(ClientToServerCmd)

typedef boost::shared_ptr<ClientToServerCmd> Cmd_ptr;


class BeginCmd : public ClientToServerCmd {
public:
	BeginCmd(const std::string& suiteName, bool createJobs)
	: suiteName_(suiteName), createJobs_(createJobs) {}
	BeginCmd() :  createJobs_(true) {}

	const std::string& suiteName() const { return suiteName_;}
	bool createJobs() const { return createJobs_;}

  	virtual std::ostream& print(std::ostream& os) const;
  	virtual bool equals(Cmd*) const;

private:
	std::string suiteName_;
	bool        createJobs_;

	friend class boost::serialization::access;
	template<class Archive>
	void serialize( Archive & ar, const unsigned int /*version*/ ) {
 		ar & boost::serialization::base_object< ClientToServerCmd >( *this );
		ar & suiteName_;
		ar & createJobs_;
 	}
};

std::ostream& operator<<(std::ostream& os, const BeginCmd&);

#endif
