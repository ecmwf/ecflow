//================ ClientToServerRequest.hpp =========================
#ifndef CLIENT_TO_SERVER_REQUEST_HPP_
#define CLIENT_TO_SERVER_REQUEST_HPP_

#include <boost/noncopyable.hpp>
#include "Cmd.hpp"

class ClientToServerRequest : private boost::noncopyable {
public:

	ClientToServerRequest() {}
	ClientToServerRequest(Cmd_ptr cmd) : cmd_(cmd) {  }
 	~ClientToServerRequest() {}

	void set_cmd(Cmd_ptr cmd) { cmd_ = cmd;  }

	std::ostream& print(std::ostream& os) const;

 	/// Used by boost test, to verify persistence
	bool operator==(const ClientToServerRequest& rhs) const;
	void save(const std::string& filename) const;
	void restore(const std::string& filename );

private:
	Cmd_ptr cmd_;
    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int /*version*/) {
        ar & cmd_;
    }
};

std::ostream& operator<<(std::ostream& os, const ClientToServerRequest& d);

#endif
