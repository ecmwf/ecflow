//================ Main.cpp =========================
// This example demonstrates a unregistered void cast exception
// that is specific only to the AIX compiler. (i.e HPUX/Acc and
// linux/gcc run without any problems)
//
// This test consists of 5 files
// 1/ Main.cpp
// 2/ Cmd.hpp
// 3/ Cmd.cpp
// 4/ ClientToServerRequest.hpp
// 4/ ClientToServerRequest.cpp
//
#include <iostream>
#include <vector>
#include <boost/foreach.hpp>
#include "ClientToServerRequest.hpp"

using namespace std;

int main()
{
	std::vector<Cmd_ptr> cmd_vec;
	cmd_vec.push_back( Cmd_ptr( new BeginCmd("suiteName",false))); // must be first

	BOOST_FOREACH(const Cmd_ptr& theCmd, cmd_vec) {

		const ClientToServerRequest cmd_request(theCmd); // MUST be const to avoid AIX compiler warning
		cmd_request.save( "request.txt");
		std::cout << "Save request " << cmd_request << "\n";

		ClientToServerRequest restoredRequest;
		restoredRequest.restore("request.txt");
		assert(restoredRequest == cmd_request);

		std::cout << "Restored " << restoredRequest << "\n";
	}
	return 0;
}
